package schemavalidation;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class ValidateSchema {

	@Test
	public void create() {
		
		// End point
				RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
				
				//Authentication
				
				RestAssured.authentication=RestAssured.oauth2("FmbiDInFyHw--1q7m9Zk3Lio6csoHX7ooYvLkSDcvhPY9orHsL_YDBmg7_LzmzainPu6XhUeHrhqD0CfxUIymg");
				
				//Add Request
				
				RequestSpecification input = RestAssured.given()
				.contentType("application/json")
				.accept("application/json")
				.queryParam("sysparm_fields", "short_description,sys_id")
				.when().body("{\r\n"
						+ "    \"short_description\": \"test description\",\r\n"
						+ "    \"work_notes\": \"created by\"\r\n"
						+ "}");
				
				// Send Request 
				
				Response response = input.post();
				
				File schemaFile=new File("./src/test/resources/JsonSchema.json");
				
				response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schemaFile));				
				
				
				
		
	}
}
