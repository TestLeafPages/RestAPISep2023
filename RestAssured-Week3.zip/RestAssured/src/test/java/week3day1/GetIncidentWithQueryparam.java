package week3day1;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetIncidentWithQueryparam {
	
	@Test
	public void getIncident() {
		
		// End point
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Test@123");
		
		//Add a Single Query Parameter
		RequestSpecification input = RestAssured.given()
	    .queryParam("sysparm_fields", "short_description,sys_id");
		
		//Send Request
		Response response = input.get();
		List<Object> sysidList= response.jsonPath().getList("result.sys_id");
		System.out.println("Total number of incidents"+sysidList.size());
		
	//	response.prettyPrint();
		
		
		
		
	}

}
