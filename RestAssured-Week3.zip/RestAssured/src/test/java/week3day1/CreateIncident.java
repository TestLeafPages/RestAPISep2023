package week3day1;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
	
	@Test
	public void create() {
		
		// End point
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Test@123");
		
		//Add Request
		
		RequestSpecification input = RestAssured.given()
		.contentType("application/json")
		.accept("application/json")
		.when().body("{\r\n"
				+ "    \"short_description\": \"test description\",\r\n"
				+ "    \"work_notes\": \"created by\"\r\n"
				+ "}");
		
		// Send Request 
		
		Response response = input.post();
		
		String sys_id = response.jsonPath().get("result.sys_id");
		
		System.out.println("The Extracted Sysid is -------"+sys_id);
		
		int statusCode = response.getStatusCode();
		System.out.println("My Status code is "+statusCode);
		
		response.prettyPrint();
		
		
		
		
		
		
		
	}

}
