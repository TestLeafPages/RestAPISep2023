package week3day1;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DeleteIncident {

	@Test
	public void delete() {
		
		// End point
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Test@123");
		
		//Send Request
		
		Response response = RestAssured.delete("/8d3c7e0c2f61311081e256f62799b607");
		
		System.out.println(response.getStatusCode());
	}
}
