package week3day1;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentQPS {
	
	@Test
	public void getAll() {
		
		Map<String,String> queryparams=new HashMap<String,String>();
		queryparams.put("sysparm_fields", "short_description,sys_id");
		queryparams.put("sysparm_limit", "1");
		
		// End point
				RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
				
				//Authentication
				
				RestAssured.authentication=RestAssured.basic("admin", "Test@123");
				
				//Add a Single Query Parameter
				RequestSpecification input = RestAssured.given()
			    .queryParams(queryparams);
				
				Response response = input.get();
				
				response.prettyPrint();
	}

}
