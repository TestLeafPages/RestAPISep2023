package chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident extends BaseClass {

	@Test(dependsOnMethods = "chaining.CreateIncident.create") //packageame.className.methodName
	public void update() {


		// Add Request

		input = RestAssured.given()
				.contentType("application/json")
				.when()
				.body("{\"short_description\":\"Updated via RestAssured\"}");

		//Send Request

		response = input.put("/"+sys_ID);

		response.prettyPrint();

	}

}
