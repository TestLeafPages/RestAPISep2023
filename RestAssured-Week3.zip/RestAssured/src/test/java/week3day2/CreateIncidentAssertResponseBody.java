package week3day2;

import java.io.File;

import org.hamcrest.Matchers;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentAssertResponseBody {

	
	@Test
	public void incident() {
		
		 //Endpoint
         RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Test@123");
		
		File fileName=new File("./src/test/resources/CreateIncident.json");
		
		//Form the Request Body
		
		RequestSpecification input = RestAssured.given().contentType("application/json")
		.when().body(fileName);
		
		//Send Request
		
		Response response = input.post();
		
		int statusCode = response.getStatusCode();
		
	    // Assert.assertEquals(statusCode, 200);
		
		// Assert response body using Hamcrest
		
		response.then().assertThat().body("result.number", Matchers.containsString("INC"));
		
		//response.then().assertThat().body("result.number", Matchers.containsString("XYZ"));
		
		
		
		response.prettyPrint();
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
