package week3day2;

import java.util.List;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AssertGetAllIncidents {
	
	@Test
	public void getIncidents() {
		
		
		// End point
		RestAssured.baseURI="https://dev90367.service-now.com/api/now/table/incident";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "Test@123");
		
		//Add a Single Query Parameter
		RequestSpecification input = RestAssured.given();
		
		//Send Request
		Response response = input.get();
		List<Object> sysidList= response.jsonPath().getList("result.sys_id");
		System.out.println("Total number of incidents"+sysidList.size());
		
		//out of 2163 incidents validate in the response whether INC0012580 is present
		
		//response.then().assertThat().body("result.number", Matchers.hasItem("INC0012580"));
		response.then().assertThat().body("result.number", Matchers.hasItem("INC00125801"));
	
	}

}
